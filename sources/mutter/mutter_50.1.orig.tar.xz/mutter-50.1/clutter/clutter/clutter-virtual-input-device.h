/*
 * Clutter.
 *
 * An OpenGL based 'interactive canvas' library.
 *
 * Copyright (C) 2016  Red Hat inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library. If not, see <http://www.gnu.org/licenses/>.
 *
 * Author: Jonas Ådahl <jadahl@gmail.com>
 */

#pragma once

#include <glib-object.h>
#include <stdint.h>

#include "clutter/clutter-seat.h"

#define CLUTTER_TYPE_VIRTUAL_INPUT_DEVICE (clutter_virtual_input_device_get_type ())

#define CLUTTER_VIRTUAL_INPUT_DEVICE_MAX_TOUCH_SLOTS 32u

CLUTTER_EXPORT
G_DECLARE_DERIVABLE_TYPE (ClutterVirtualInputDevice,
                          clutter_virtual_input_device,
                          CLUTTER, VIRTUAL_INPUT_DEVICE,
                          GObject)

typedef enum _ClutterButtonState
{
  CLUTTER_BUTTON_STATE_RELEASED,
  CLUTTER_BUTTON_STATE_PRESSED
} ClutterButtonState;

typedef enum _ClutterKeyState
{
  CLUTTER_KEY_STATE_RELEASED,
  CLUTTER_KEY_STATE_PRESSED
} ClutterKeyState;

struct _ClutterVirtualInputDeviceClass
{
  GObjectClass parent_class;

  void (*notify_relative_motion) (ClutterVirtualInputDevice *virtual_device,
                                  uint64_t                   time_us,
                                  double                     dx,
                                  double                     dy);

  void (*notify_absolute_motion) (ClutterVirtualInputDevice *virtual_device,
                                  uint64_t                   time_us,
                                  double                     x,
                                  double                     y);

  void (*notify_button) (ClutterVirtualInputDevice *virtual_device,
                         uint64_t                   time_us,
                         uint32_t                   button,
                         ClutterButtonState         button_state);

  void (*notify_key) (ClutterVirtualInputDevice *virtual_device,
                      uint64_t                   time_us,
                      uint32_t                   key,
                      ClutterKeyState            key_state);
  void (*notify_keyval) (ClutterVirtualInputDevice *virtual_device,
                         uint64_t                   time_us,
                         uint32_t                   keyval,
                         ClutterKeyState            key_state);

  void (*notify_discrete_scroll) (ClutterVirtualInputDevice *virtual_device,
                                  uint64_t                   time_us,
                                  ClutterScrollDirection     direction,
                                  ClutterScrollSource        scroll_source);

  void (*notify_scroll_continuous) (ClutterVirtualInputDevice *virtual_device,
                                    uint64_t                   time_us,
                                    double                     dx,
                                    double                     dy,
                                    ClutterScrollSource        scroll_source,
                                    ClutterScrollFinishFlags   finish_flags);

  void (*notify_touch_down) (ClutterVirtualInputDevice *virtual_device,
                             uint64_t                   time_us,
                             int                        slot,
                             double                     x,
                             double                     y);

  void (*notify_touch_motion) (ClutterVirtualInputDevice *virtual_device,
                               uint64_t                   time_us,
                               int                        slot,
                               double                     x,
                               double                     y);

  void (*notify_touch_up) (ClutterVirtualInputDevice *virtual_device,
                           uint64_t                   time_us,
                           int                        slot);
};

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_relative_motion (ClutterVirtualInputDevice *virtual_device,
                                                          uint64_t                   time_us,
                                                          double                     dx,
                                                          double                     dy);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_absolute_motion (ClutterVirtualInputDevice *virtual_device,
                                                          uint64_t                   time_us,
                                                          double                     x,
                                                          double                     y);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_button (ClutterVirtualInputDevice *virtual_device,
                                                 uint64_t                   time_us,
                                                 uint32_t                   button,
                                                 ClutterButtonState         button_state);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_key (ClutterVirtualInputDevice *virtual_device,
                                              uint64_t                   time_us,
                                              uint32_t                   key,
                                              ClutterKeyState            key_state);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_keyval (ClutterVirtualInputDevice *virtual_device,
                                                 uint64_t                   time_us,
                                                 uint32_t                   keyval,
                                                 ClutterKeyState            key_state);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_discrete_scroll (ClutterVirtualInputDevice *virtual_device,
                                                          uint64_t                   time_us,
                                                          ClutterScrollDirection     direction,
                                                          ClutterScrollSource        scroll_source);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_scroll_continuous (ClutterVirtualInputDevice *virtual_device,
                                                            uint64_t                   time_us,
                                                            double                     dx,
                                                            double                     dy,
                                                            ClutterScrollSource        scroll_source,
                                                            ClutterScrollFinishFlags   finish_flags);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_touch_down (ClutterVirtualInputDevice *virtual_device,
                                                     uint64_t                   time_us,
                                                     int                        slot,
                                                     double                     x,
                                                     double                     y);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_touch_motion (ClutterVirtualInputDevice *virtual_device,
                                                       uint64_t                   time_us,
                                                       int                        slot,
                                                       double                     x,
                                                       double                     y);

CLUTTER_EXPORT
void clutter_virtual_input_device_notify_touch_up (ClutterVirtualInputDevice *virtual_device,
                                                   uint64_t                   time_us,
                                                   int                        slot);

CLUTTER_EXPORT
int clutter_virtual_input_device_get_device_type (ClutterVirtualInputDevice *virtual_device);

CLUTTER_EXPORT
ClutterSeat * clutter_virtual_input_device_get_seat (ClutterVirtualInputDevice *virtual_device);
